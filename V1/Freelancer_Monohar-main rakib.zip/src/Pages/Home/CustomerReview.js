import React from 'react';
import styled from 'styled-components';

const CustomerReview = () => {

    const CustomerReviewCard = styled.div`
    
    
    
    
    `










    return (
        <>

            
        </>
    );
};

export default CustomerReview;