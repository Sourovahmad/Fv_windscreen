import massage from "./Images/Massage.svg"
import padicure from "./Images/Pedicure.svg"
import facial from "./Images/Facial.svg"
import barber from "./Images/Barber.svg"
import menicure from "./Images/Manicure.svg"
import footMassage from "./Images/Foot-Massage.svg"

const ServiceIconData = [
    {
        name: "Massage",
        iconImg:massage,
    },
    {
        name: "Massage",
        iconImg: padicure,
    },
    {
        name: "Massage",
        iconImg: facial,
    },
    {
        name: "Massage",
        iconImg: barber,
    },
    {
        name: "Massage",
        iconImg: menicure,
    },
    {
        name: "Massage",
        iconImg: footMassage,
    },
    {
        name: "Massage",
        iconImg:massage,
    },
    {
        name: "Massage",
        iconImg: padicure,
    },
    {
        name: "Massage",
        iconImg: facial,
    },
    {
        name: "Massage",
        iconImg: barber,
    },
    {
        name: "Massage",
        iconImg: menicure,
    },
    {
        name: "Massage",
        iconImg: footMassage,
    },
];

export {ServiceIconData}